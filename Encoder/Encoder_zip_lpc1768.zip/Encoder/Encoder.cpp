/*#include <Encoder.h>

Encoder::Encoder(char _address){address == _address;}
void Encoder::updatePosition(Serial& SerialPort){
    serialPort.putc(address);   //Encoder Read Command
    if(encoder.readable()) {
        position = encoder.getc() << 8; //Lower Byte
        position |= encoder.getc();     //Upper Byte
        position &= 0x3FFF;             //Removing Check Bits
        if (resolution == 12) position = position >> 2;
    }
}
uint16_t Encoder::getPosistion(){return position;}

/*
float encoderPositionToAngle (uint16_t position){
   return (float)((position * 1.0) / ( 2 ^ resolution));
}
*/