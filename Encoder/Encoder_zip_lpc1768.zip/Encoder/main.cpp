#include "mbed.h"
#include <Encoder.h>

#define TX        p9
#define RX        p10

#define encoder_baud        9600
#define encoder_resolution  (1 << 12)
#define resolution 12
float encoderPositionToAngle(uint16_t position);
bool checksum(uint16_t data);

Serial pc(USBTX, USBRX); // tx, rx
Serial encoder(TX, RX, encoder_baud);

int main() {
    pc.printf("Hello World!\n\r");
    char D[1] = {0xF0};
    uint16_t position = 0;
    pc.printf("Talking to Encoder\n\r");
    while(1) {
        encoder.putc(D[0]);

        if(encoder.readable()) {
            position = encoder.getc() << 8; //Lower Byte
            position |= encoder.getc();     //Upper Byte
            
            if(!(checksum(position)==1)){
                position &= 0x3FFF;             //Removing Check Bits
                if (resolution == 12) position = position >> 2;
                float angle = encoderPositionToAngle(position);
                pc.printf("Position: %d\n\rAngle: %f\n\r",position, angle);
                pc.printf("\n\r\n\r\n\r");
            }/*else{
                pc.printf("FAILED CHECKSUM!");
                pc.printf("\n\r\n\r\n\r");
            }*/
            
        }
        wait(0.1);
    }
    
    /*
    pc.printf("Hello World!\n\r");
    Encoder encoder(0xF0);
    while(1){
        pc.printf("Talking to Encoder\n\r");   
        encoder.updatePosition();
        pc.printf("Position: %d",encoder.getPosition(););
        pc.printf("\n\r\n\r\n\r");
    }
    */
}
//Assuming Odd Parity
bool checksum(uint16_t data){
    bool checksum = 0;
    uint8_t cbe = 0;    //Even Checker
    uint8_t cbo = 0;    //Odd Checker
    
    if(data & (1<<14)){ cbe++; }
    if(data & (1<<15)){ cbo++; }
    
    for(int i=0; i<8; i++){
        if(data & (1<<i*2)){ cbe++; }       //Checking Even Bits
        if(data & (1<<(i*2+1))){ cbo++; }   //Checking Odd Bits
    }
    
    if(!(cbe%2==1 && cbo%2==1)){ checksum = 1; }
    return checksum;
}

float encoderPositionToAngle(uint16_t position){
    return (float)position/11.3777;
}

