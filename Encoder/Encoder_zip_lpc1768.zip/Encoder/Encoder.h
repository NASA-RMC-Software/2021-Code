#include <mbed.h>
#define resolution = 12
/*
class Encoder{
    private:
        char address[1] = {0x00};
        uint16_t position = 0;
    public:
        Encoder(char _address){}
        void updatePosition(Serial* serialPort);
        uint16_t getPosistion();
}       */